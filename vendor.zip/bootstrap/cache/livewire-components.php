<?php return array (
  'categories' => 'App\\Http\\Livewire\\Categories',
  'certificationfilter' => 'App\\Http\\Livewire\\Certificationfilter',
  'certifications' => 'App\\Http\\Livewire\\Certifications',
  'exam-vouchers' => 'App\\Http\\Livewire\\ExamVouchers',
  'exams' => 'App\\Http\\Livewire\\Exams',
  'products' => 'App\\Http\\Livewire\\Products',
  'search-dropdown' => 'App\\Http\\Livewire\\SearchDropdown',
  'vendorfilter' => 'App\\Http\\Livewire\\Vendorfilter',
  'vendors' => 'App\\Http\\Livewire\\Vendors',
);