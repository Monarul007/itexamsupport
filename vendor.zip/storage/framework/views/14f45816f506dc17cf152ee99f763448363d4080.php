

<?php $__env->startSection('content'); ?>

<div class="app-page-title">
    <div class="page-title-wrapper">
        <div class="page-title-heading">
            <div class="page-title-icon">
                <i class="pe-7s-car icon-gradient bg-mean-fruit"></i>
            </div>
            <div>Admin Dashboard
                <div class="page-title-subheading">Control your App Features and functionality from here!</div>
            </div>
        </div>
        <div class="page-title-actions">
            <button type="button" data-toggle="tooltip" title="All Vendors" data-placement="bottom" class="btn-shadow mr-3 btn btn-dark">
                <i class="pe-7s-medal"></i>
            </button>
        </div>    
    </div>
</div>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('exam-vouchers')->html();
} elseif ($_instance->childHasBeenRendered('6xVtPh4')) {
    $componentId = $_instance->getRenderedChildComponentId('6xVtPh4');
    $componentTag = $_instance->getRenderedChildComponentTagName('6xVtPh4');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('6xVtPh4');
} else {
    $response = \Livewire\Livewire::mount('exam-vouchers');
    $html = $response->html();
    $_instance->logRenderedChild('6xVtPh4', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\123web\htdocs\ITExam\resources\views/admin/vouchers/all-vouchers.blade.php ENDPATH**/ ?>