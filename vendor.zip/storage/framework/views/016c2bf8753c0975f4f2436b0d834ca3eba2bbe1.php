<div class="input-group search-input mb-2 position-relative">
    <input type="text" class="form-control" placeholder="Enter exam code or title here..." aria-label="Enter Your Text" aria-describedby="basic-addon2" wire:model="searchTerm">
    <div class="input-group-append">
        <button class="btn btn-outline-success" type="button">SEARCH</button>
    </div>
    <div class="search-results position-absolute" style="width: 100%; top: 57px; z-index: 1;">
        <div class="card border-0">
            <ul class="list-group list-group-flush">
                <?php if($searchTerm): ?>
                    <?php if($results->count() > 0): ?>
                        <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item bg-light border" style="padding: 5px 16px;"><a href="/exam/<?php echo e($r->id); ?>"><?php echo e($r->exam_title); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <li class="list-group-item">No results found!</li>
                    <?php endif; ?>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</div><?php /**PATH E:\123web\htdocs\ITExam\resources\views/livewire/search-dropdown.blade.php ENDPATH**/ ?>