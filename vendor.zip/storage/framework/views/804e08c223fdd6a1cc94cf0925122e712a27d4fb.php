

<?php $__env->startSection('content'); ?>

<div class="app-page-title">
    <div class="page-title-wrapper">
        <div class="page-title-heading">
            <div class="page-title-icon">
                <i class="pe-7s-car icon-gradient bg-mean-fruit"></i>
            </div>
            <div>Certifications
                <div class="page-title-subheading">Control all your certification Features and functionality from here!</div>
            </div>
        </div>
        <div class="page-title-actions">
            <button type="button" data-toggle="tooltip" title="All Certification" data-placement="bottom" class="btn-shadow mr-3 btn btn-dark">
                <i class="pe-7s-target"></i>
            </button>
        </div>    
    </div>
</div>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('certifications')->html();
} elseif ($_instance->childHasBeenRendered('M4wqXcS')) {
    $componentId = $_instance->getRenderedChildComponentId('M4wqXcS');
    $componentTag = $_instance->getRenderedChildComponentTagName('M4wqXcS');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('M4wqXcS');
} else {
    $response = \Livewire\Livewire::mount('certifications');
    $html = $response->html();
    $_instance->logRenderedChild('M4wqXcS', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\123web\htdocs\ITExam\resources\views/admin/certifications/all-certifications.blade.php ENDPATH**/ ?>