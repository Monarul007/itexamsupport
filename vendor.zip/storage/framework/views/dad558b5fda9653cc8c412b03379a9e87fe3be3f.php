                        <div class="row">
                            <div class="col-md-12">
                                <div>
                                    <?php if(session()->has('message')): ?>
                                        <div class="alert alert-success">
                                            <?php echo e(session('message')); ?>

                                        </div>
                                    <?php endif; ?>
                                </div>
                                <?php if($updateMode): ?>
                                    <?php echo $__env->make('livewire.exams.update', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php else: ?>
                                    <?php echo $__env->make('livewire.exams.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php endif; ?>
                                <div class="main-card mt-4 mb-3 card">
                                    <div class="card-header">All Exams
                                        <div class="btn-actions-pane-right">
                                            <div role="group" class="btn-group-sm btn-group">
                                                <button type="button" class="border-0 btn-transition btn btn-outline-primary"><i class="pe-7s-plus"></i> Add New Exam</button>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="table-responsive">
                                        <table class="align-middle mb-0 table table-borderless table-striped table-hover">
                                            <thead>
                                                <tr>
                                                    <th class="text-center">#</th>
                                                    <th>Name</th>
                                                    <th class="text-center">Vendor</th>
                                                    <th class="text-center">Certification</th>
                                                    <th class="text-center">Code</th>
                                                    <th class="text-center">Questions</th>
                                                    <th class="text-center">Status</th>
                                                    <th class="text-center">Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                            <?php if($exams->count() > 0): ?>
                                                <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td class="text-center text-muted">#<?php echo e($exam->id); ?></td>
                                                        <td><?php echo e($exam->exam_title); ?></td>
                                                        <td><?php echo e($exam->vendor->name); ?></td>
                                                        <td><?php echo e($exam->certification->title); ?></td>
                                                        <td><?php echo e($exam->exam_code); ?></td>
                                                        <td><?php echo e($exam->total_questions); ?></td>
                                                        <td class="text-center">
                                                            <?php if($exam->status == 1): ?>
                                                                <div class="badge badge-success">Active</div>
                                                            <?php else: ?>
                                                                <div class="badge badge-warning">Inactive</div>
                                                            <?php endif; ?>
                                                        </td>
                                                        <td class="text-center" style="min-width: 150px;">
                                                            <button class="mr-2 btn-icon btn-icon-only btn btn-outline-danger"><i class="pe-7s-trash btn-icon-wrapper" wire:click="delete(<?php echo e($exam->id); ?>)"> </i></button>
                                                            <button class="btn-wide btn btn-primary" wire:click="edit(<?php echo e($exam->id); ?>)">Edit</button>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                                <tr><td class="text-danger text-center" colspan="8">No exam found. Please add some exam</td></tr>
                                            <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="d-block text-center card-footer">
                                        <div class="text-center">You can manage exam, view, edit and delete exams from here...</div>
                                    </div>
                                </div>
                            </div>
                        </div>
<?php /**PATH E:\XAMPP\htdocs\ITExam\ITExam\resources\views/livewire/exams.blade.php ENDPATH**/ ?>