
<?php $__env->startSection('content'); ?>
<div class="app-page-title">
    <div class="page-title-wrapper">
        <div class="page-title-heading">
            <div class="page-title-icon">
                <i class="pe-7s-car icon-gradient bg-mean-fruit"></i>
            </div>
            <div>Products
                <div class="page-title-subheading">Control all your product features and functionality from here!</div>
            </div>
        </div>
        <div class="page-title-actions">
            <button type="button" data-toggle="tooltip" title="All Products" data-placement="bottom" class="btn-shadow mr-3 btn btn-dark">
                <i class="pe-7s-target"></i>
            </button>
        </div>    
    </div>
</div>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('products')->html();
} elseif ($_instance->childHasBeenRendered('5zPVH5U')) {
    $componentId = $_instance->getRenderedChildComponentId('5zPVH5U');
    $componentTag = $_instance->getRenderedChildComponentTagName('5zPVH5U');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('5zPVH5U');
} else {
    $response = \Livewire\Livewire::mount('products');
    $html = $response->html();
    $_instance->logRenderedChild('5zPVH5U', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\ABC\htdocs\ITExam\resources\views/admin/products/all-products.blade.php ENDPATH**/ ?>