

<?php $__env->startSection('content'); ?>

<div class="container mt-4">
    <div class="row">
        <div class="col-md-3 pr-0">
            <div class="card mb-3">
                <div class="card-body pt-0 m-2">
                <?php if(auth()->guard()->guest()): ?>
                    <form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group row">
                            <label for="email"><?php echo e(__('Email')); ?></label>
                                <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group row">
                            <label for="password"><?php echo e(__('Password')); ?></label>

                                <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password">

                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group row">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>

                                    <label class="form-check-label" for="remember">
                                        <?php echo e(__('Remember Me')); ?>

                                    </label>
                                </div>
                        </div>

                        <div class="form-group row mb-0">
                            
                                <button type="submit" class="btn btn-primary btn-sm">
                                    <?php echo e(__('SIGN IN')); ?>

                                </button>

                                <?php if(Route::has('password.request')): ?>
                                    <a class="btn btn-link btn-sm" href="<?php echo e(route('password.request')); ?>">
                                        <?php echo e(__('Forgot Password?')); ?>

                                    </a>
                                <?php endif; ?>
                            
                        </div>
                    </form>
                    <?php else: ?>
                    <div class="row"><span class="small"><b>Welcome <?php echo e(Auth::user()->name); ?></b></span></div>
                    <div class="row"><p class="small">You have No Product in your Member's Area of ITExam Support.</p></div>
                    <div class="row">
                    <a class="btn btn-primary btn-sm" href="<?php echo e(route('logout')); ?>"
                        onclick="event.preventDefault();
                                        document.getElementById('logout-form').submit();">
                        <?php echo e(__('Logout')); ?>

                    </a>
                        <?php if(Route::has('password.request')): ?>
                            <a class="btn btn-link btn-sm" href="<?php echo e(route('password.request')); ?>">
                                <?php echo e(__('Forgot Password?')); ?>

                            </a>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
                </div>
            </div>
            <table id="myTable">
                <tr class="header">
                    <th style="width:60%;">Top Vendor Included</th>
                </tr>
                <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><a href="/vendors/<?php echo e($vendor->id); ?>"><?php echo e($vendor->name); ?></a></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr class="footer">
                    <th style="width:60%;"><a href="<?php echo e(route('all.products')); ?>">View All Vendors</a></th>
                </tr>
            </table>
        </div>
        <div class="col-md-9">
            <h4 style="color:#333399;background: #f5f5f5;padding: 10px;font-size: 16px;font-weight: bold;border: 1px solid #e5e5e5;margin-bottom: 10px;margin-top: 0;text-transform: uppercase;"><?php echo e($vv->name); ?></h4>
            <h4 style="color:#333399;background: #f5f5f5;padding: 10px;font-size: 16px;font-weight: bold;border: 1px solid #e5e5e5;margin-bottom: 10px;margin-top: 0;text-transform: uppercase; text-align: center;">Complete list of <?php echo e($vv->name); ?> certifications and exams available.</h4>
            <div class="row mt-2 mb-5">
                <div class="col-12">
                    <?php $__currentLoopData = $certifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="table-responsive">
                            <table id="example" class="table table-bordered table-sm">
                                <thead class="text-white text-center">
                                    <tr>
                                        <th>Certification</th>
                                        <th>Exam</th>
                                        <th>Title</th>
                                        <th>No. of Q&A</th>
                                        <th>Last Updated</th>
                                    </tr>
                                    <tr>
                                        <td height="50" align="center" colspan="5" style="border-bottom: 1px solid #d0dde6;font-size: 14px;color: #164ea5;background: #fff;vertical-align: middle;"><strong><?php echo e($c->title); ?></strong></td>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if($c->exams->count() > 0): ?>
                                        <?php $__currentLoopData = $c->exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="text-center"><?php echo e($exam->certification->title); ?></td>
                                            <td class="text-center"><a href="/exam/<?php echo e($exam->id); ?>"><?php echo e($exam->exam_code); ?></a></td>
                                            <td class="text-center"><?php echo e($exam->exam_title); ?></td>
                                            <td class="text-center"><?php echo e($exam->total_questions); ?></td>
                                            <td class="text-center"><?php echo e(($exam->updated_at->format('j F, Y'))); ?></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td height="30" width="750" colspan="5"><i class="fa fa-arrow-up"></i><a href="#top"> Top</a></td>
                                        </tr>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="5" class="text-center text-danger">No exams available to display under this vendor!</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\ABC\htdocs\ITExam\resources\views/single-vendor.blade.php ENDPATH**/ ?>