            <div class="row">
                <div class="col-12">
                    <?php if($message = Session::get('message')): ?>
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>	
                        <strong><?php echo e($message); ?></strong>
                    </div>
                    <?php endif; ?>
                </div>
                <div class="col-md-6 grid-margin stretch-card">
                    <div class="card">
                        <div class="card-body">
                            <?php if($updateMode): ?>
                                <?php echo $__env->make('livewire.categories.update', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php else: ?>
                                <?php echo $__env->make('livewire.categories.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="main-card mb-3 card">
                        <div class="card-body">
                            <h5 class="card-title"><?php if($categories->count() > 0): ?> <?php echo e(count($categories).' Category found.'); ?> <?php else: ?> <b class="text-danger">No category found!</b> <?php endif; ?></h5>
                            <table class="mb-0 table table-bordered table-sm">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Name</th>
                                        <th>Slug</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if($categories->count() > 0): ?>
                                        <?php $i = 1; ?>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td scope="row"><?php echo e($i++); ?></td>
                                                <td class="text-center"><?php echo e($category->name); ?></td>
                                                <td class="text-center"><?php echo e($category->url); ?></td>
                                                <td class="text-center"><button wire:click="edit(<?php echo e($category->id); ?>)" class="btn btn-outline-primary btn-sm mr-2"><i class="fa fa-edit"> Edit</i></button><button wire:click="remove(<?php echo e($category->id); ?>)" class="btn btn-outline-danger btn-sm"><i class="fa fa-trash"> Delete</i></button></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="6" class="text-center"><span class="text-danger">No categoty to show! You can add category from left side form.</span></td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div><?php /**PATH E:\ABC\htdocs\ITExam\resources\views/livewire/categories.blade.php ENDPATH**/ ?>