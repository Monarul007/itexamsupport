

<?php $__env->startSection('content'); ?>

<div class="app-page-title">
    <div class="page-title-wrapper">
        <div class="page-title-heading">
            <div class="page-title-icon">
                <i class="pe-7s-car icon-gradient bg-mean-fruit"></i>
            </div>
            <div>Admin Dashboard
                <div class="page-title-subheading">Control your App Features and functionality from here!</div>
            </div>
        </div>
        <div class="page-title-actions">
            <button type="button" data-toggle="tooltip" title="All Vendors" data-placement="bottom" class="btn-shadow mr-3 btn btn-dark">
                <i class="pe-7s-medal"></i>
            </button>
        </div>    
    </div>
</div>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('vendors')->html();
} elseif ($_instance->childHasBeenRendered('AWEy3zl')) {
    $componentId = $_instance->getRenderedChildComponentId('AWEy3zl');
    $componentTag = $_instance->getRenderedChildComponentTagName('AWEy3zl');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('AWEy3zl');
} else {
    $response = \Livewire\Livewire::mount('vendors');
    $html = $response->html();
    $_instance->logRenderedChild('AWEy3zl', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\XAMPP\htdocs\ITExam\ITExam\resources\views/admin/vendors/vendors.blade.php ENDPATH**/ ?>