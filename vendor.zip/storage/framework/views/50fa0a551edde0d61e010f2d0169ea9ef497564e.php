<div class="row" id="top">
    <div class="col-12">
        <?php if($updateMode): ?>
            <?php echo $__env->make('livewire.products.update', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php elseif($createMode): ?>
            <?php echo $__env->make('livewire.products.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
    </div>
    <div class="col-12">
        <?php if($message = Session::get('message')): ?>
        <div class="alert alert-success alert-block">
            <button type="button" class="close" data-dismiss="alert">×</button>	
            <strong><?php echo e($message); ?></strong>
        </div>
        <?php endif; ?>
        <h5 class="card-title"><?php if($products->count() > 0): ?> <?php echo e(count($products).' products found.'); ?> <?php else: ?> <b class="text-danger">No product found!</b> <?php endif; ?></h5>
        <div class="grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <div class="card-title d-flex">All Products
                        <div class="ml-auto">
                            <button href="#top" wire:click.prevent="foo()" class="btn-transition btn btn-outline-primary btn-sm"><i class="fa fa-plus-circle" aria-hidden="true"></i> Add new product</button>
                        </div>
                    </div>
                    <table class="mb-0 table table-bordered table-sm">
                        <thead class="text-center">
                            <tr>
                                <th>SL.</th>
                                <th>Image</th>
                                <th>Name</th>
                                <th>Category</th>
                                <th>Price</th>
                                <th>isFeatured</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($products->count() > 0): ?>
                                <?php $i = 1; ?>
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($i++); ?></th>
                                        <th class="text-center">
                                            <?php if($product->image): ?> 
                                                <?php $__currentLoopData = json_decode($product->image); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <img src="<?php echo e(asset('storage/'.$item.'')); ?>" alt="" height="30" width="30">
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?> 
                                                <img src="/images/cat-thumb-320x320.png" alt="" height="48" width="48">
                                            <?php endif; ?>
                                        </th>
                                        <td class="text-center"><?php echo e($product->name); ?></td>
                                        <td class="text-center"><?php echo e($product->category->name); ?></td>
                                        <td class="text-center"><?php echo e($product->price); ?></td>
                                        <td class="text-center">
                                            <?php if($product->is_featured == 1): ?>
                                            <div class="badge badge-success">Featured</div>
                                            <?php else: ?>
                                            <div class="badge badge-warning">General</div>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-center"><button wire:click="edit(<?php echo e($product->id); ?>)" class="btn btn-outline-primary btn-sm mr-2"><i class="fa fa-edit"> Edit</i></button><button wire:click="delete(<?php echo e($product->id); ?>)" class="btn btn-outline-danger btn-sm"><i class="fa fa-trash"> Delete</i></button></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="7" class="text-center"><span class="text-danger">No product to show! <button wire:click.prevent="foo()" class="btn btn-link btn-sm"><i class="fa fa-plus-circle" aria-hidden="true"></i> Add new product</button></span></td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH E:\ABC\htdocs\ITExam\resources\views/livewire/products.blade.php ENDPATH**/ ?>