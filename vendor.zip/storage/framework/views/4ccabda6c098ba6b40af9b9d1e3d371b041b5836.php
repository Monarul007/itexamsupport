<h5 class="card-title">Update Category</h5>
<form enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <input type="hidden" wire:model="cat_id">
    <div class="position-relative form-group">
        <div class="d-flex">
            <span data-toggle="tooltip" title="The name is how it appears on your site." data-placement="right" class="mr-2"><i class="pe-7s-help1"></i></span>
            <label for="url" class=""> Name</label>
        </div>
        <input type="text" class="form-control" wire:model="name" placeholder="Enter Category Name">
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="position-relative form-group">
        <div class="d-flex">
            <span data-toggle="tooltip" title="The “slug” is the URL-friendly version of the name. It is usually all lowercase and contains only letters, numbers, and hyphens." data-placement="right" class="mr-2"><i class="pe-7s-help1"></i></span>
            <label for="url" class="">Slug</label>
        </div>
        <input type="text" wire:model="url" class="form-control" id="url" placeholder="Enter url">
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="position-relative form-group">
        <div class="d-flex">
            <span data-toggle="tooltip" title="Assign a parent term to create a hierarchy. The term Jazz, for example, would be the parent of Bebop and Big Band." class="mr-2"><i class="pe-7s-help1"></i></span>
            <label for="url" class="">Parent Category</label>
        </div>
        <select class="custom-select" wire:model="parent">
            <option value="0">Main Category</option>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($cat->id); ?>" <?php if($loop->first): ?> selected <?php endif; ?>><?php echo e($cat->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php $__errorArgs = ['parent'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="position-relative form-group">
        <div class="d-flex">
            <span data-toggle="tooltip" title="The description is not prominent by default; however, some themes may show it." class="mr-2"><i class="pe-7s-help1"></i></span>
            <label for="url" class="">Description</label>
        </div>
        <textarea type="text" wire:model="desc" class="form-control" placeholder="Enter Description"></textarea>
        <?php $__errorArgs = ['desc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <button class="btn btn-primary mr-2" wire:click.prevent="update()">Update</button>
    <button class="btn btn-danger" wire:click.prevent="cancel()">Cancel</button>
</form><?php /**PATH E:\ABC\htdocs\ITExam\resources\views/livewire/categories/update.blade.php ENDPATH**/ ?>