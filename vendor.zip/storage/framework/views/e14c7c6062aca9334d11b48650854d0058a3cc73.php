
<?php $__env->startSection('content'); ?>
<div class="app-page-title">
    <div class="page-title-wrapper">
        <div class="page-title-heading">
            <div class="page-title-icon">
                <i class="pe-7s-car icon-gradient bg-mean-fruit"></i>
            </div>
            <div>Categories
                <div class="page-title-subheading">Control all your category features and functionality from here!</div>
            </div>
        </div>
        <div class="page-title-actions">
            <button type="button" data-toggle="tooltip" title="All Categories" data-placement="bottom" class="btn-shadow mr-3 btn btn-dark">
                <i class="pe-7s-target"></i>
            </button>
        </div>    
    </div>
</div>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('categories')->html();
} elseif ($_instance->childHasBeenRendered('hvFSElR')) {
    $componentId = $_instance->getRenderedChildComponentId('hvFSElR');
    $componentTag = $_instance->getRenderedChildComponentTagName('hvFSElR');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('hvFSElR');
} else {
    $response = \Livewire\Livewire::mount('categories');
    $html = $response->html();
    $_instance->logRenderedChild('hvFSElR', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\ABC\htdocs\ITExam\resources\views/admin/categories/categories.blade.php ENDPATH**/ ?>