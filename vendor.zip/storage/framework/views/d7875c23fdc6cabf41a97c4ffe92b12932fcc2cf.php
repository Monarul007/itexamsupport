<h5 class="card-title">Create a new product</h5>
<form wire:submit.prevent="update()" class="mb-5">
    <input type="hidden" wire:model="product_id">
    <div class="form-row">
        <div class="col-md-7">
            <div class="position-relative form-group">
                <input type="text" class="form-control" wire:model="name" placeholder="Enter product name">
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <div class="col-md-5">
            <div class="position-relative form-group">
                <select class="custom-select" wire:model="category">
                    <option selected>Select Category</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($cat->id); ?>" <?php if($loop->first): ?> selected <?php endif; ?>><?php echo e($cat->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
    </div>
    <div class="form-row">
        <div class="col-md-6">
            <?php if($discountMode): ?>
                <div class="form-group">
                    <input type="number" class="form-control" wire:model="price" placeholder="Product price" min="1">
                    <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <div class="d-flex"><label for="discountType">Discount Type</label><button wire:click.prevent="disable()" class="btn-transition btn btn-link btn-sm ml-auto"><i class="fa fa-plus-circle" aria-hidden="true"></i> Disable Discount</button></div>
                    <select class="custom-select" wire:model="discountType" id="discountType">
                        <option value="0" selected>Percantage</option>
                        <option value="1">Flat Discount</option>
                    </select>
                    <?php $__errorArgs = ['discountType'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <input type="number" class="form-control" wire:model="amount" value="0" min="0" placeholder="Discount amount or percantage">
                    <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            <?php else: ?>
                <div class="row">
                    <div class="col-6 form-group">
                        <input type="text" class="form-control" wire:model="price" placeholder="Product price">
                    </div>
                    <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <div class="col-6"><button wire:click.prevent="discount()" class="btn-transition btn btn-link"><i class="fa fa-plus-circle" aria-hidden="true"></i> Enable Discount</button></div>
                </div>
            <?php endif; ?>
            <div class="position-relative form-group">
                <textarea wire:model="description" class="form-control" rows="8" placeholder="Enter product description"></textarea>
                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <div class="col-md-6">
            <p>Optional Details</p>
            <div class="position-relative form-group"><input type="text" class="form-control" wire:model="code" placeholder="Enter product code"></div>
            <div class="position-relative form-group"><textarea wire:model="specs" class="form-control" rows="8" placeholder="Enter product specifications"></textarea></div>
        </div>
    </div>
    <div class="col-12">
        <div class="position-relative form-group row">
            <div class="row">
                <div class="col-md-6">
                    <?php if($prevPhotos): ?>
                        <p>Photos:</p>
                        <div class="d-flex">
                            <?php $__currentLoopData = $prevPhotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="image-block position-relative d-flex">
                                <img src="<?php echo e(asset('storage/'.$item.'')); ?>" width="70" style="height: 70px; border-radius: 10px;"><i class="fa fa-times-circle" style="position: absolute;left: 0;color: #fff;cursor: pointer;"></i>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="col-md-6">
                    <?php if($photos): ?>
                        <p>New Photos:</p>
                        <div class="d-flex">
                            <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="image-block position-relative d-flex" wire:key="<?php echo e($loop->index); ?>">
                                <img src="<?php echo e($photo->temporaryUrl()); ?>" width="70" style="height: 70px; border-radius: 10px;"><i class="fa fa-times-circle" style="position: absolute;left: 0;color: #fff;cursor: pointer;" wire:click="remove(<?php echo e($loop->index); ?>)"></i>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="custom-file">
                <input type="file" wire:model="photos" class="custom-file-input" id="photos" multiple>
                <label class="custom-file-label" for="photos">Choose Product Images</label>
            </div>
            <div wire:loading wire:target="photos">Uploading...</div>
            <?php $__errorArgs = ['photos.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
    <button type="submit" class="btn btn-primary mr-2">Update Product</button>
    <button wire:click.prevent="cancel()" class="btn btn-danger">Cancel</button>
</form><?php /**PATH E:\ABC\htdocs\ITExam\resources\views/livewire/products/update.blade.php ENDPATH**/ ?>