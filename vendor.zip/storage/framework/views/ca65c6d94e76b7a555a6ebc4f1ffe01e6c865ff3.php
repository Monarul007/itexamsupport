<form>
    <div class="position-relative row form-group">
        <label for="VendorName" class="col-sm-2 col-form-label">Vendor Name</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" id="VendorName" placeholder="Enter Name Here.." wire:model="VendorName">
            <?php $__errorArgs = ['VendorName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
    <div class="position-relative row form-group">
        <label for="VendorDesc" class="col-sm-2 col-form-label">Vendor Description</label>
        <div class="col-sm-10">
            <textarea id="VendorDesc" class="form-control" wire:model="VendorDesc" placeholder="Enter Description"></textarea>
            <?php $__errorArgs = ['VendorDesc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
    <div class="position-relative row form-group">
        <label for="VendorType" class="col-sm-2 col-form-label">Select</label>
        <div class="col-sm-10">
            <select id="VendorType" class="form-control" wire:model="VendorType">
                <option selected value="0">Regular</option>
                <option value="1">Featured</option>
            </select>
            <?php $__errorArgs = ['VendorType'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
    <div class="position-relative row form-check">
        <div class="col-sm-10 offset-sm-2">
            <button wire:click.prevent="create()" class="btn btn-secondary">Add Vendor</button>
        </div>
    </div>
</form><?php /**PATH E:\XAMPP\htdocs\ITExam\ITExam\resources\views/livewire/vendors/create.blade.php ENDPATH**/ ?>