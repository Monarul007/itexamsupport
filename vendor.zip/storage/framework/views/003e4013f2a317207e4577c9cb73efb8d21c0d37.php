            <div class="row mt-5 mb-5">
                <div class="col-12">
                    <h3>Exams Available</h3>
                    <div class="select-vendor p-3 border">
                        <form style="max-width: 50%; margin: auto;">
                            <div class="form-group row">
                                <label for="vendor" class="col-sm-4 col-form-label">Select Vendor</label>
                                <div class="col-sm-7">
                                    <select class="custom-select" wire:model="vendor" wire:change="results()" id="vendor">
                                        <option value="">Select Vendor</option>
                                        <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($vendor->id); ?>" <?php if($loop->first): ?> selected <?php endif; ?>><?php echo e($vendor->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <?php $__errorArgs = ['vendor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </form>
                    </div>
                    <?php if($singleMode): ?>
                        <?php echo $__env->make('livewire.vendors.single-vendor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php else: ?>
                        <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="exam-title"><?php echo e($v->name); ?></div>
                        <div class="table-responsive">
                            <table id="example" class="table table-bordered table-sm">
                                <thead class="text-white text-center">
                                    <tr>
                                        <th>Certification</th>
                                        <th>Exam</th>
                                        <th>Title</th>
                                        <th>No. of Q&A</th>
                                        <th>Last Updated</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if($v->exams->count() > 0): ?>
                                        <?php $__currentLoopData = $v->exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="text-center"><?php echo e($exam->certification->title); ?></td>
                                            <td class="text-center"><a href="exam/<?php echo e($exam->id); ?>"><?php echo e($exam->exam_code); ?></a></td>
                                            <td class="text-center"><?php echo e($exam->exam_title); ?></td>
                                            <td class="text-center"><?php echo e($exam->total_questions); ?></td>
                                            <td class="text-center"><?php echo e(($exam->updated_at->format('j F, Y'))); ?></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td height="30" width="750" colspan="5"><i class="fa fa-arrow-up"></i><a href="#top"> Top</a></td>
                                        </tr>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="5" class="text-center text-danger">No exams available to display under this vendor!</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
<?php /**PATH E:\123web\htdocs\ITExam\resources\views/livewire/vendorfilter.blade.php ENDPATH**/ ?>