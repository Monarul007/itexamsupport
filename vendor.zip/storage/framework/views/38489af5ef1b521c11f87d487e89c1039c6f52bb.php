            <div class="row mt-2 mb-5">
                <div class="col-md-12">
                    <table id="cert" class="table table-bordered table-sm">
                        <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="header">
                                <th class="text-white" style="background: #164ea5;"><?php echo e($v->name); ?></th>
                            </tr>
                            <?php if($v->certifications->count() > 0): ?>
                                <?php $__currentLoopData = $v->certifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><a href="vendors/<?php echo e($v->id); ?>"><?php echo e($c->title); ?></a></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <tr>
                                    <td class="text-danger">No certification found under this vendor.</td>
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
<?php /**PATH E:\ABC\htdocs\ITExam\resources\views/livewire/certificationfilter.blade.php ENDPATH**/ ?>