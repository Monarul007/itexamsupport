

<?php $__env->startSection('content'); ?>

<div class="app-page-title">
    <div class="page-title-wrapper">
        <div class="page-title-heading">
            <div class="page-title-icon">
                <i class="pe-7s-car icon-gradient bg-mean-fruit"></i>
            </div>
            <div>Exams
                <div class="page-title-subheading">Control all your exams features and functionality from here!</div>
            </div>
        </div>
        <div class="page-title-actions">
            <button type="button" data-toggle="tooltip" title="All Exams" data-placement="bottom" class="btn-shadow mr-3 btn btn-dark">
                <i class="pe-7s-target"></i>
            </button>
        </div>    
    </div>
</div>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('exams')->html();
} elseif ($_instance->childHasBeenRendered('lex2W5P')) {
    $componentId = $_instance->getRenderedChildComponentId('lex2W5P');
    $componentTag = $_instance->getRenderedChildComponentTagName('lex2W5P');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('lex2W5P');
} else {
    $response = \Livewire\Livewire::mount('exams');
    $html = $response->html();
    $_instance->logRenderedChild('lex2W5P', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\123web\htdocs\ITExam\resources\views/admin/exams/all-exams.blade.php ENDPATH**/ ?>