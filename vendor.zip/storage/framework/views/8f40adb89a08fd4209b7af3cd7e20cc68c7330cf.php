
                    <div class="exam-title"><?php echo e($vv->name); ?></div>
                    <div class="table-responsive">
                        <table id="example" class="table table-bordered table-sm">
                            <thead class="text-white text-center">
                                <tr>
                                    <th>Certification</th>
                                    <th>Exam</th>
                                    <th>Title</th>
                                    <th>No. of Q&A</th>
                                    <th>Last Updated</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if($vv->exams->count() > 0): ?>
                                    <?php $__currentLoopData = $vv->exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="text-center"><?php echo e($exam->certification->title); ?></td>
                                        <td class="text-center"><a href="/exam/<?php echo e($exam->id); ?>"><?php echo e($exam->exam_code); ?></a></td>
                                        <td class="text-center"><?php echo e($exam->exam_title); ?></td>
                                        <td class="text-center"><?php echo e($exam->total_questions); ?></td>
                                        <td class="text-center"><?php echo e(($exam->updated_at->format('j F, Y'))); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="5" class="text-center text-danger">No exams available to display under this vendor!</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div><?php /**PATH E:\ABC\htdocs\ITExam\resources\views/livewire/vendors/single-vendor.blade.php ENDPATH**/ ?>